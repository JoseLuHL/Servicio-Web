﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Xml;

namespace WcfService1
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
    // NOTE: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione Service1.svc o Service1.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
        public string server_Hosting()
        {
            string res = "";
            try
            {
                string server = "workstation id=prueba001.mssql.somee.com;packet size=4096;user id=joseph04_SQLLogin_1;pwd=26f8hpywqk;data source=prueba001.mssql.somee.com;persist security info=False;initial catalog=prueba001";
                SqlConnection cnn = new SqlConnection(server);
                cnn.Open();
                res = cnn.State.ToString();
            }
            catch (Exception ex)
            {
                res = ex.ToString();
            }

            return res;
        }

        public string server()
        {
            string res = "";
            try
            {
                String servidor = @"DESKTOP-PV6C33B\SQLEXPRESS";
                String usuario = "prueba";
                String password = "2019";
                String database = "HistoriaClinica";
                string server = String.Format("Data Source={0};Initial Catalog={1};User ID={2};Password={3}", servidor, database, usuario, password);

                SqlConnection cnn = new SqlConnection(server);
                cnn.Open();
                res = cnn.State.ToString();
            }
            catch (Exception ex)
            {
                res = ex.ToString();
            }

            return res;
        }

        //public static MySqlConnection probarConexion()
        //{
        //    MySqlConnection con;
        //    String servidor = "localhost";
        //    String puerto = "3306";
        //    String usuario = "root";
        //    String password = "2019";
        //    String database = "pruba";
        //    string Sesion;
        //    //Cadena de conexion
        //    Sesion = String.Format("server={0};port={1};user id={2}; password={3}; database={4}", servidor, puerto, usuario, password, database);
        //    con = new MySqlConnection(Sesion);
        //    con.Open();//se abre la conexion
        //    return con;
        //}

        public string obtenerRegistro()
        {
            DataTable tablaDatos = new DataTable();
            string server = "workstation id=prueba001.mssql.somee.com;packet size=4096;user id=joseph04_SQLLogin_1;pwd=26f8hpywqk;data source=prueba001.mssql.somee.com;persist security info=False;initial catalog=prueba001";
            string CadenaConexion = server;
                //"Data Source=192.168.0.110;Initial Catalog=HistoriaClinica;Persist Security Info=True;User ID=usuhistoria;Password=2018";
            SqlConnection conectar = new SqlConnection(CadenaConexion);
            conectar.Open();
            SqlDataAdapter cmd = new SqlDataAdapter("Select * from Cliente", conectar);
            DataSet data = new DataSet();
            cmd.Fill(data, "datos");
            tablaDatos = data.Tables[0];
            string registro = "";
            for (int iCampo = 0; iCampo < tablaDatos.Rows.Count; iCampo++)
            {
                Array a = tablaDatos.Rows[iCampo].ItemArray;
                for (int indice = 0; indice < a.Length; indice++)
                {
                    registro += a.GetValue(indice).ToString() + ",";
                }
                registro += "/";
            }
            return registro;
        }
        public DataTable TablaReistros()
        {
            DataTable tablaDatos = new DataTable();
            string CadenaConexion = "Data Source=192.168.0.110;Initial Catalog=HistoriaClinica;Persist Security Info=True;User ID=usuhistoria;Password=2018";
            SqlConnection conectar = new SqlConnection(CadenaConexion);
            conectar.Open();
            SqlDataAdapter cmd = new SqlDataAdapter("Select * from paciente", conectar);
            DataSet data = new DataSet();
            cmd.Fill(data, "datos");
            tablaDatos = data.Tables[0];
            return tablaDatos;
        }
        public string GuardarXML(string Elemento1, string Elemento2, string Elemento3, string Elemento4)
        {
            string Respuesta = "";
            try
            {
                //RAIZ DEL DOCUMENTO
                XmlDocument document = new XmlDocument();
                XmlElement ElemenRaiz = document.CreateElement("Raiz");
                document.AppendChild(ElemenRaiz);

                XmlElement libro = document.CreateElement("Raiz_Sub");
                ElemenRaiz.AppendChild(libro);

                XmlElement titulo = document.CreateElement("Titulo");
                titulo.AppendChild(document.CreateTextNode("PONER TITULO"));
                libro.AppendChild(titulo);

                XmlElement Elm1 = document.CreateElement("Elemento1");
                Elm1.AppendChild(document.CreateTextNode(Elemento1));
                libro.AppendChild(Elm1);

                XmlElement Elm2 = document.CreateElement("Elemento2");
                Elm2.AppendChild(document.CreateTextNode(Elemento2));
                libro.AppendChild(Elm2);

                XmlElement Elm3 = document.CreateElement("Elemento3");
                Elm3.AppendChild(document.CreateTextNode(Elemento3));
                libro.AppendChild(Elm3);

                XmlElement Elm4 = document.CreateElement("Elemento3");
                Elm4.AppendChild(document.CreateTextNode(Elemento4));
                libro.AppendChild(Elm4);

                document.Save("c:\\xml\\Archivo.hml");
                Respuesta = "Archivo Guardado";
            }
            catch (Exception ex)
            {
                Respuesta = "Error " + ex.ToString();

            }
            return Respuesta;
        }
        public string IniciarSesion(string usuario, string contraseña)
        {
            string respuesta = "";
            try
            {                
                DataTable tablaDatos = new DataTable();
                string CadenaConexion = "Data Source=192.168.0.110;Initial Catalog=HistoriaClinica;Persist Security Info=True;User ID=usuhistoria;Password=2018";
                SqlConnection conectar = new SqlConnection(CadenaConexion);
                conectar.Open();
                SqlDataAdapter ad = new SqlDataAdapter("SELECT [Usu_NombreCompleto] FROM [dbo].[Usuario] WHERE Usu_Nombre = '" + usuario + "' And Usu_Contraseña ='" + contraseña + "'", conectar);
                DataSet data = new DataSet();
                ad.Fill(data, "datos");
                if (data.Tables[0].Rows.Count == 1)
                {
                    respuesta = data.Tables[0].Rows[0][0].ToString();
                }
            }
            catch (Exception ex)
            {
                respuesta = ex.ToString();
            }
          
            return respuesta;
        }
        public string ConsultarCliente( string Identificacion)
        {
            DataTable tablaDatos = new DataTable();
            string CadenaConexion = "Data Source=192.168.0.110;Initial Catalog=HistoriaClinica;Persist Security Info=True;User ID=usuhistoria;Password=2018";
            SqlConnection conectar = new SqlConnection(CadenaConexion);
            conectar.Open();
            string sql = "SELECT [Cli_Identificacion] " +
                        ", CONCAT ([Cli_Nombre1], + ' '+ isnull([Cli_Nombre2],''), + ' '+ [Cli_Apellido1] " +
                        ", isnull([Cli_Apellido2],'')) as NombreCompleto FROM[dbo].Cliente " +
                        "WHERE Cli_Identificacion = '" + Identificacion + "'";
            SqlDataAdapter cmd = new SqlDataAdapter(sql, conectar);
            DataSet data = new DataSet();
            cmd.Fill(data, "datos");            
            string registro = "";
            if (data.Tables[0].Rows.Count>0)
            {
                registro = data.Tables[0].Rows[0]["NombreCompleto"].ToString();
            }
            return registro;
        }        
        public DataTable ConsultarProductos()
        {
            DataTable tablaDatos = new DataTable();
            string CadenaConexion = "Data Source=192.168.0.110;Initial Catalog=HistoriaClinica;Persist Security Info=True;User ID=usuhistoria;Password=2018";
            SqlConnection conectar = new SqlConnection(CadenaConexion);
            conectar.Open();
            SqlDataAdapter cmd = new SqlDataAdapter("select* from producto", conectar);
            DataSet data = new DataSet();
            cmd.Fill(data, "datos");
            tablaDatos = data.Tables[0];
            return tablaDatos;
        }
        public DataTable ConsultarProductosListaPrecio(string codProducto,string Identificacion)
        {
            DataTable tablaDatos = new DataTable();
            string CadenaConexion = "Data Source=192.168.0.110;Initial Catalog=HistoriaClinica;Persist Security Info=True;User ID=usuhistoria;Password=2018";
            SqlConnection conectar = new SqlConnection(CadenaConexion);
            conectar.Open();
            string sql = "SELECT  dbo.ListaPrecioDetalle.ListProd_CodProducto, " +
                "dbo.ListaPrecioDetalle.ListProd_VrUnitario,       " +
                "dbo.Cliente.Cli_Identificacion, dbo.Producto.Prod_Existencia,                   " +
                "dbo.Producto.Prod_Descripcion                     " +
                "FROM    dbo.ListaPrecio INNER JOIN                " +
                "dbo.ListaPrecioDetalle ON                         " +
                "dbo.ListaPrecio.List_Codigo =                     " +
                "dbo.ListaPrecioDetalle.ListProd_CodLista          " +
                "INNER JOIN dbo.Producto ON                        " +
                "dbo.ListaPrecioDetalle.ListProd_CodProducto =     " +
                "dbo.Producto.Prod_Codigo                          " +
                "INNER JOIN dbo.Cliente ON                         " +
                "dbo.ListaPrecioDetalle.ListProd_CodLista =        " +
                "dbo.Cliente.Cli_CodLista                          " +
                "WHERE Cli_Identificacion='" + Identificacion + "' and ListProd_CodProducto='" + codProducto + "'";
            SqlDataAdapter cmd = new SqlDataAdapter(sql, conectar);
            DataSet data = new DataSet();
            cmd.Fill(data, "datos");
            tablaDatos = data.Tables[0];
            return tablaDatos;
        }
    }
}
